import GlobalStyle from "./GlobalStyle";
import styled from "styled-components";

const Container = styled.div`
	display: flex;
	justify-content: center;
	align-items: center;
	width: 100%;
	height: 100%;
	border: 2px solid black;
`;

const Parent = styled.div`
	width: 80%;
	background-color: teal;
	border: 2px solid red;
	display: grid;
	grid-template-columns: repeat(4, 1fr);
	grid-template-rows: 200px 200px 200px 200px;
	grid-template-areas:
		"header header header header"
		"main main main sidebar"
		"main main main sidebar"
		"footer footer footer footer";

	@media screen and (max-width: 640px) {
		grid-template-rows: 200px 200px 200px 200px 200px;
		grid-template-areas:
			"header header header header"
			"main main main main"
			"main main main main"
			"sidebar sidebar sidebar sidebar"
			"footer footer footer footer";
	}
`;
const Header = styled.header`
	grid-area: header;
	background-color: blue;
`;
const Main = styled.main`
	grid-area: main;
	background-color: green;
`;
const Sidebar = styled.aside`
	grid-area: sidebar;
	background-color: dodgerblue;
`;
const Footer = styled.footer`
	grid-area: footer;
	background-color: pink;
`;

function App() {
	return (
		<>
			<GlobalStyle />
			<Container>
				<Parent>
					<Header>헤더</Header>
					<Main>메인</Main>
					<Sidebar>사이드바</Sidebar>
					<Footer>Footer</Footer>
				</Parent>
			</Container>
		</>
	);
}

export default App;
